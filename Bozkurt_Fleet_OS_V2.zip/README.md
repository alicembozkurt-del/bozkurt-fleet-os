# Bozkurt Fleet OS V2

Includes: Loads, Expenses, Fuel, Fixed Costs, Assets, Loans, Maintenance, Settlements, W2 Payroll, Documents, Reports.

## iPhone test
Upload `index.html` and `manifest.json` to GitHub Pages, then open the Pages link in Safari and Add to Home Screen.

## PC/Mac test
Open `index.html` directly in Chrome/Safari/Edge.

## Privacy
Data is stored locally in the browser. Export JSON backup weekly.
